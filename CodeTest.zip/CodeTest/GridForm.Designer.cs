namespace GridTest
    //Formatting of the UI
{
    partial class GridForm
    {       
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnLoadCsv;

        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnLoadCsv = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1 
            // 
            dataGridView1.Location = new Point(12, 50);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(760, 400);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellDoubleClick += DataGridView1_CellDoubleClick;
            // 
            // btnLoadCsv
            // 
            btnLoadCsv.Location = new Point(12, 12);
            btnLoadCsv.Name = "btnLoadCsv";
            btnLoadCsv.Size = new Size(120, 30);
            btnLoadCsv.TabIndex = 1;
            btnLoadCsv.Text = "Load CSV";
            btnLoadCsv.Click += BtnClickLoad;
            // 
            // Form1
            // 
            ClientSize = new Size(784, 461);
            Controls.Add(dataGridView1);
            Controls.Add(btnLoadCsv);
            Name = "Form1";
            Text = "CSV GridView Viewer";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }
    }
}
