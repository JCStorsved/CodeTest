namespace GridTest
    //format the cell pop up
{
    partial class CellViewForm
    {        
        private System.Windows.Forms.Label lblValue;

        private void InitializeComponent()
        {
            this.lblValue = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // lblValue
            this.lblValue.AutoSize = true;
            this.lblValue.Location = new System.Drawing.Point(20, 20);
            this.lblValue.Size = new System.Drawing.Size(100, 20);
            this.lblValue.Text = "";

            // CellViewForm
            this.ClientSize = new System.Drawing.Size(300, 100);
            this.Controls.Add(this.lblValue);
            this.Text = "Cell Value";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
