//initialize the cell pop up info

namespace GridTest
{
    public partial class CellViewForm : Form
    {
        public CellViewForm(string cellValue, string title)
        {
            InitializeComponent();
            this.Text = title;
            lblValue.Text = cellValue;
        }
    }
}
