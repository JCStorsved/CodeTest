using System.Data;

//Functions to handle events of the form
namespace GridTest
{
    public partial class GridForm : Form
    {
        public GridForm()
        {
            InitializeComponent();
        }
        //Handling of clicking the Load CSV button
        private void BtnClickLoad(object sender, EventArgs e)
        {
            //We want to handle errors gracefully
            try
            {
                OpenFileDialog dialog = new()
                {
                    Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*"
                };
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = dialog.FileName;
                    DataTable table = LoadCsvToDataTable(filePath);
                    dataGridView1.DataSource = table;
                }
            }
            catch (Exception ex)
            {
                LogError("Failed to load CSV file.", ex);
                MessageBox.Show("An error occurred while loading the CSV file. Check the log on your desktop.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Loading the data from the CSV to the table
        private static DataTable LoadCsvToDataTable(string path)
        {
            DataTable table = new();
            using (StreamReader reader = new(path))
            {
                bool isFirstLine = true;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(','); //The null value will still pass in, it will be a blank entry in the grid. The try catch will catch it if there is a problem displaying on the double click.

                    if (isFirstLine)
                    {
                        foreach (var header in values)
                            table.Columns.Add(header.Trim());
                        isFirstLine = false;
                    }
                    else
                    {
                        table.Rows.Add(values);
                    }
                }
            }
            return table;
        }

        //Handle double clicking of cell
        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    string? value = dataGridView1[e.ColumnIndex, e.RowIndex].Value?.ToString();
                    string title = $"Cell [{e.ColumnIndex}, {e.RowIndex}]";
                    CellViewForm viewForm = new(value, title); //The try catch will catch if a problem arises if a null value is entered. Otherwise a person could put a check here for null and do some other work.
                    viewForm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                LogError($"Failed to open cell viewer for cell [{e.RowIndex}, {e.ColumnIndex}].", ex);
                MessageBox.Show("An error occurred while opening the cell view. Check the log on your desktop.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Log any errors to file on desktop
        private void LogError(string message, Exception? ex = null)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string logFilePath = Path.Combine(desktopPath, "GridTest_Log.txt");

            using (StreamWriter writer = new StreamWriter(logFilePath, append: true))
            {
                writer.WriteLine("[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] ERROR:");
                writer.WriteLine("  " + message);
                if (ex != null)
                {
                    writer.WriteLine("  Exception: " + ex.Message);
                    writer.WriteLine("  StackTrace: " + ex.StackTrace);
                }
                writer.WriteLine(); // Empty line between logs
            }
        }

        //Load the Form
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
